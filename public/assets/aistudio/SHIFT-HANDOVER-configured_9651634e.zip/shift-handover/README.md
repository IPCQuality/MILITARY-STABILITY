# SHIFT HANDOVER — Military & Stability

Aplikasi web serah terima informasi antar-shift. Frontend statis dapat di-host di GitHub Pages, sedangkan autentikasi dan data disimpan di Supabase Cloud.

## Fitur pada starter ini
- Login dan pendaftaran akun email/password.
- Data bersama antar pengguna yang sudah login.
- Input laporan Shift 1, Shift 2, dan Shift 3.
- Kategori Overhaul, Stability Tinggi, Case Perbaikan Part, dan Commissioning/Trial/Change Over.
- Edit laporan sebelumnya.
- Dashboard dan filter history.
- Export Excel `.xlsx` dengan sheet `HANDOVER` dan `DETAIL DATA`.

## 1. Buat project Supabase
1. Buka https://supabase.com/ lalu buat project baru.
2. Masuk ke **SQL Editor**.
3. Buka file `supabase-schema.sql`, salin seluruh isinya, lalu jalankan.
4. Buka **Project Settings → API**.
5. Salin `Project URL` dan `anon/public key`.

## 2. Hubungkan aplikasi ke Supabase
Konfigurasi project yang telah diberikan sudah dipasang pada `app.js`:
- Project URL: `https://dkyjfoxruqoqlhxrmcac.supabase.co`
- Key: `sb_publishable_...` (Publishable key)

Publishable key memang boleh berada di frontend. Keamanan data tetap wajib dijaga dengan Row Level Security (RLS).

**Jangan pernah memasukkan `secret` atau `service_role` key ke frontend, GitHub, atau file yang dibagikan.** Jika key publishable dirotasi di Supabase, ganti konstanta `SUPABASE_PUBLISHABLE_KEY` pada `app.js` dengan publishable key yang baru.

## 3. Buat akun pengguna
- Jalankan aplikasi melalui GitHub Pages atau server lokal.
- Daftar akun dengan email dan password.
- Jika konfirmasi email aktif, buka email untuk verifikasi sebelum login.
- Setiap operator/shift dapat menggunakan akun masing-masing.

## 4. Deploy ke GitHub Pages
1. Buat repository GitHub, misalnya `SHIFT-HANDOVER`.
2. Upload `index.html`, `styles.css`, `app.js`, `supabase-schema.sql`, dan README.
3. Buka **Settings → Pages**.
4. Pilih branch `main`, folder `/ (root)`, lalu Save.
5. Buka URL GitHub Pages yang diberikan.

## Catatan keamanan dan operasional
- Kebijakan RLS pada starter ini mengizinkan semua pengguna yang sudah login membaca dan mengedit seluruh laporan. Ini sesuai kebutuhan agar shift berikutnya dapat memperbarui laporan sebelumnya.
- Penghapusan data tidak disediakan di UI.
- Siapa pun yang memiliki akun terdaftar dapat masuk. Untuk penggunaan internal perusahaan, pertimbangkan mematikan public sign-up setelah akun operator dibuat, lalu admin membuat akun pengguna.
- Jangan menyimpan data rahasia perusahaan atau informasi sensitif sebelum kebijakan akses disesuaikan dengan aturan internal.
- Export Excel mengambil laporan berdasarkan tanggal filter di History; bila filter tanggal kosong, export menggunakan tanggal hari ini.
- Library Supabase dan SheetJS dimuat dari CDN, sehingga koneksi internet diperlukan.

## Pengembangan berikutnya
- Hak akses Admin / Operator.
- Penguncian shift setelah diserahkan (opsional).
- Log audit perubahan (siapa mengubah apa dan kapan).
- Template Excel yang meniru format laporan final secara persis.
- Upload foto bukti pekerjaan bila dibutuhkan.


## Status konfigurasi saat paket ini diperbarui
- Project URL dan Publishable key telah dimasukkan ke `app.js` berdasarkan nilai yang diberikan pengguna.
- SQL schema belum dapat dinyatakan berhasil dijalankan sampai hasil `Run` terlihat di Supabase SQL Editor.
- GitHub Pages, akun multiuser, sinkronisasi, edit lintas-shift, history, dan ekspor Excel masih perlu diuji setelah database aktif dan aplikasi dideploy.
