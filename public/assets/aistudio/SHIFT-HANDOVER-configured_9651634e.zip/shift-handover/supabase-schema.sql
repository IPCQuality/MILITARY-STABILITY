-- Jalankan seluruh script ini di Supabase Dashboard > SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.handover_entries (
  id uuid primary key default gen_random_uuid(),
  report_date date not null,
  shift smallint not null check (shift between 1 and 3),
  category text not null check (category in (
    'OVERHAUL',
    'STABILITY TINGGI',
    'CASE PERBAIKAN PART',
    'COMMISSIONING/TRIAL/CHANGE OVER'
  )),
  machine text,
  information text not null,
  issue text default '',
  follow_up text default '',
  created_by uuid not null references auth.users(id) on delete restrict,
  created_by_email text default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists handover_entries_date_idx
  on public.handover_entries(report_date desc);
create index if not exists handover_entries_shift_idx
  on public.handover_entries(report_date, shift);

alter table public.handover_entries enable row level security;

-- Hak akses API untuk pengguna yang sudah login; RLS tetap menjadi pembatas utama.
grant select, insert, update on table public.handover_entries to authenticated;

-- Semua pengguna yang sudah login dapat melihat seluruh laporan,
-- menambah laporan, serta memperbarui laporan shift sebelumnya.
drop policy if exists "Authenticated users can read handovers" on public.handover_entries;
create policy "Authenticated users can read handovers"
  on public.handover_entries for select to authenticated using (true);

drop policy if exists "Authenticated users can create handovers" on public.handover_entries;
create policy "Authenticated users can create handovers"
  on public.handover_entries for insert to authenticated with check (auth.uid() = created_by);

drop policy if exists "Authenticated users can update handovers" on public.handover_entries;
create policy "Authenticated users can update handovers"
  on public.handover_entries for update to authenticated using (true) with check (true);

-- Penghapusan tidak diaktifkan dari aplikasi agar riwayat tidak terhapus tanpa sengaja.
